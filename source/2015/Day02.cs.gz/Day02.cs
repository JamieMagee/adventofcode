﻿using System;
using System.Threading.Tasks;
using AdventOfCode.Core;

namespace AdventOfCode._2015.Puzzles.Solutions
{
    [Puzzle("I Was Told There Would Be No Math")]
    public sealed class Day02 : SolutionBase
    {
        public override async Task<string> Part1Async(string input)
        { 
            throw new NotImplementedException();
        }

        public override async Task<string> Part2Async(string input)
        {
            throw new NotImplementedException();
        }
    }
}